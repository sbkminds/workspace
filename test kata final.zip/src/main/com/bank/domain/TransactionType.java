package main.com.bank.domain;

public enum TransactionType {
    DEPOSIT, WITHDRAWAL
}
